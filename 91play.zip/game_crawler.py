import requests
import pandas as pd
import json
import time
from tqdm import tqdm

class GameDistributionSimpleCrawler:
    def __init__(self):
        self.base_url = "https://catalog.api.gamedistribution.com/api/v1.0/rss/All/?collection=All&categories=All&tags=All&subType=All&type=All&mobile=All&rewarded=all&amount=100&page={}"
        self.output_file = "game_iframes.csv"
        self.output_json = "game_data.json"
        
    def fetch_games(self, pages=5):
        """获取多页游戏数据"""
        all_games = []
        
        for page in range(1, pages + 1):
            try:
                print(f"正在获取第 {page}/{pages} 页游戏列表...")
                response = requests.get(self.base_url.format(page), timeout=15)
                
                if response.status_code == 200:
                    games = response.json()
                    all_games.extend(games)
                    print(f"第 {page} 页获取到 {len(games)} 个游戏")
                    
                    # 避免请求过快
                    if page < pages:
                        time.sleep(1)
                else:
                    print(f"获取第 {page} 页失败: HTTP {response.status_code}")
                    break
                    
            except Exception as e:
                print(f"获取第 {page} 页时出错: {e}")
                continue
                
        return all_games
    
    def process_games(self, games):
        """处理游戏数据，生成iframe信息"""
        processed_games = []
        
        for game in tqdm(games, desc="处理游戏数据"):
            game_id = game.get('Md5')
            if not game_id:
                continue
            
            # 构建iframe嵌入代码
            iframe_url = f"https://html5.gamedistribution.com/{game_id}/"
            embed_code = f'<iframe src="{iframe_url}" width="{game.get("Width", 800)}" height="{game.get("Height", 600)}" scrolling="none" frameborder="0"></iframe>'
            
            processed_games.append({
                'title': game.get('Title', ''),
                'description': game.get('Description', ''),
                'instructions': game.get('Instructions', ''),
                'type': game.get('Type', ''),
                'mobile': game.get('Mobile', ''),
                'width': game.get('Width', 800),
                'height': game.get('Height', 600),
                'url': game.get('Url', ''),
                'game_id': game_id,
                'iframe_url': iframe_url,
                'embed_code': embed_code,
                'thumb': game.get('Asset', [''])[0] if game.get('Asset') and len(game.get('Asset')) > 0 else ''
            })
            
        return processed_games
    
    def save_data(self, games):
        """保存游戏数据到CSV和JSON"""
        if not games:
            print("没有游戏数据可保存")
            return
        
        # 保存完整JSON数据
        with open(self.output_json, 'w', encoding='utf-8') as f:
            json.dump(games, f, ensure_ascii=False, indent=2)
        
        # 保存到CSV
        df = pd.DataFrame(games)
        df.to_csv(self.output_file, index=False, encoding='utf-8')
        
        print(f"成功保存 {len(games)} 个游戏数据:")
        print(f"- CSV: {self.output_file}")
        print(f"- JSON: {self.output_json}")
    
    def run(self, pages=5):
        """运行完整爬虫流程"""
        print(f"开始爬取 GameDistribution 游戏数据 ({pages} 页)...")
        
        # 1. 获取游戏列表
        games = self.fetch_games(pages)
        print(f"共获取到 {len(games)} 个游戏")
        
        # 2. 处理游戏数据
        processed_games = self.process_games(games)
        print(f"成功处理 {len(processed_games)}/{len(games)} 个游戏数据")
        
        # 3. 保存数据
        self.save_data(processed_games)

if __name__ == "__main__":
    crawler = GameDistributionSimpleCrawler()
    crawler.run(pages=3)  # 默认爬取3页游戏数据 